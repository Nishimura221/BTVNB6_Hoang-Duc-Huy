public class SpecComment extends Comment{
    private String status;

    public SpecComment() {
    }

    public SpecComment(String content, int like, String status) {
        super(content, like);
        this.status = status;
    }

    @Override
    public String toString() {
        return "SpecComment: Status= "+status+" like= "+getLike()+" ,content= "+getContent();

    }
    public void setData(String s){

        for(int i=0; i<getContent().length();i++){
           if(getContent().charAt(0)>='A'&&getContent().charAt(0)<='Z'){
               s=getContent().substring(1,getContent().length());
             setContent(s);

           }
        }


    }
    public String getValue(){
        int n=getContent().length();
        if(getLike()<=n){

            return n+status;
        }
        return status;

    }
}
