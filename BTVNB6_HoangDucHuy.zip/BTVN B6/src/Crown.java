import java.util.Locale;

public class Crown {
    private String color;
    private int weight;

    public Crown() {
    }

    public Crown(String color, int weight) {
        this.color = color;
        this.weight = weight;
    }

    public String getColor() {
        String s = "";
        for(int i=0;i<color.length();i++){
            if(color.charAt(i)>='A'&&color.charAt(i)<='Z'){
                s=color.substring(0,1).toLowerCase()+color.substring(1,color.length());
            }
        }
      return s;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight+getWeight();
    }
}
